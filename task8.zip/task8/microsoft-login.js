const puppeteer = require("puppeteer");

(async () => {
  try {
    const EDGE_PATH = "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe";

    const browser = await puppeteer.launch({
      headless: false,
      executablePath: EDGE_PATH,
      defaultViewport: null,
      args: ["--start-maximized"],
    });

    const page = await browser.newPage();

    // Go to Microsoft login
    console.log("Opening Microsoft login page...");
    await page.goto("https://login.microsoftonline.com/", { waitUntil: "networkidle2" });

    // Type email (Microsoft uses #i0116)
    await page.waitForSelector("#i0116", { visible: true });
    await page.type("#i0116", "your_email@example.com");
    await page.click("#idSIButton9"); // "Next" button

    // Wait for password field (#i0118)
    await page.waitForSelector("#i0118", { visible: true });
    await page.type("#i0118", "your_password");
    await page.click("#idSIButton9"); // "Sign in" button

    // Handle "Stay signed in?" page (optional)
    try {
      await page.waitForSelector("#idBtn_Back", { timeout: 5000 });
      await page.click("#idBtn_Back"); // Click "No"
    } catch {
      console.log("No 'Stay signed in?' prompt");
    }

    // Wait for redirect
    await page.waitForNavigation({ waitUntil: "networkidle2" });

    console.log("✅ Login attempt completed!");

    // Go to Outlook
    await page.goto("https://outlook.office.com/mail/", { waitUntil: "networkidle2" });

    // Screenshot
    await page.screenshot({ path: "outlook.png" });
    console.log("📸 Screenshot saved: outlook.png");

    await browser.close();
  } catch (err) {
    console.error("❌ Error during automation:", err);
  }
})();
